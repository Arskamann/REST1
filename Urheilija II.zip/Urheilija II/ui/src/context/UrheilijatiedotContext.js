import { createContext } from "react";
const UrheilijatiedotContext = createContext();
export default UrheilijatiedotContext;
